import React from 'react'

const Typography = () => {
  return (
    <div className='content'>Typography</div>
  )
}

export default Typography