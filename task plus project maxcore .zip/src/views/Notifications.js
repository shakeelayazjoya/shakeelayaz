import React from 'react'

const Notifications = () => {
  return (
    <div className='content'>Notifications</div>
  )
}

export default Notifications