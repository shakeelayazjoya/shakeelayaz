import React, { useState } from "react";
import "./userprofile.css";

function UserProfileForm() {
  const [fullName, setFullName] = useState("");
  const [email, setEmail] = useState("");
  const [contactNumber, setContactNumber] = useState("");
  const [companyName, setCompanyName] = useState("");
  const [designation, setDesignation] = useState("");
  const [specialization, setSpecialization] = useState("");
  const [bankname, setBankName] = useState("");
  const [accounttitle, setAccountTitle] = useState("");
  const [branchcode, setBranchCode] = useState("");
  const [accountNumber, setAccountNumber] = useState("");
  const [attachment, setAttachment] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    // Your form submission logic here
    console.log("Form submitted:", {
      fullName,
      email,
      contactNumber,
      companyName,
      designation,
      specialization,
      attachment,
    });
    // Reset form fields
    setFullName("");
    setEmail("");
    setContactNumber("");
    setCompanyName("");
    setDesignation("");
    setSpecialization("");
    setAttachment("");
    setAccountNumber('');
    setAccountTitle("");
    setBankName("");
    setBranchCode("");
  };

  return (
    <div className="container-fluid content ">
      <div className="row">
        <div className="col-md-6">
          <form className="form" onSubmit={handleSubmit}>
            <h2>User Profile</h2>
            <div className="form-group">
              <label htmlFor="name">Full Name:</label>
              <div className="relative">
                <input
                  className="form-control"
                  id="name"
                  type="text"
                  pattern="[a-zA-Z\s]+"
                  required
                  autoFocus
                  title="Username should only contain letters. e.g. Piyush Gupta"
                  autoComplete="off"
                  placeholder="Type your name here..."
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                />
                <i className="fa fa-user"></i>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="email">Email address:</label>
              <div className="relative">
                <input
                  className="form-control"
                  type="email"
                  required
                  placeholder="Type your email address..."
                  pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                />
                <i className="fa fa-envelope"></i>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="contactNumber">Contact Number:</label>
              <div className="relative">
                <input
                  className="form-control"
                  type="text"
                  maxLength="10"
                  onInput={(e) =>
                    (e.target.value = e.target.value.replace(/[^0-9]/g, ""))
                  }
                  required
                  placeholder="Type your Mobile Number..."
                  value={contactNumber}
                  onChange={(e) => setContactNumber(e.target.value)}
                />
                <i className="fa fa-phone"></i>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="companyName">Company Name:</label>
              <div className="relative">
                <input
                  className="form-control"
                  type="url"
                  pattern="https?://.+"
                  required
                  placeholder="Mention your company link(url)..."
                  value={companyName}
                  onChange={(e) => setCompanyName(e.target.value)}
                />
                <i className="fa fa-building"></i>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="designation">Designation:</label>
              <div className="relative">
                <input
                  className="form-control"
                  type="text"
                  id="designation"
                  required
                  placeholder="Type your designation..."
                  value={designation}
                  onChange={(e) => setDesignation(e.target.value)}
                />
                <i className="fa fa-suitcase"></i>
              </div>
            </div>
            <div className="form-group">
              <label htmlFor="specialization">Specialization:</label>
              <div className="relative">
                <input
                  className="form-control"
                  type="text"
                  id="specialization"
                  required
                  placeholder="Type your specialization..."
                  value={specialization}
                  onChange={(e) => setSpecialization(e.target.value)}
                />
                <i className="fa fa-suitcase"></i>
              </div>
            </div>
           
            <div className="tright">
              <button className="movebtn movebtnre" type="reset">
                <i className="fa fa-fw fa-refresh"></i> Reset
              </button>
              <button className="movebtn movebtnsu" type="submit">
                Submit <i className="fa fa-fw fa-paper-plane"></i>
              </button>
            </div>
          </form>
        </div>



        {/* another section */}
        <div className="col-md-6">
          
            <form className="form" onSubmit={handleSubmit}>
              <h2>Bank Details</h2>
              <div className="form-group">
                <label htmlFor="name">Bank Name </label>
                <div className="relative">
                  <input
                    className="form-control"
                    id="name"
                    type="text"
                    pattern="[a-zA-Z\s]+"
                    required
                    autoFocus
                    title="Username should only contain letters. e.g. Piyush Gupta"
                    autoComplete="off"
                    placeholder="Type your name here..."
                    value={bankname}
                    onChange={(e) => setFullName(e.target.value)}
                  />
                  <i className="fa fa-user"></i>
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="email">Account Title </label>
                <div className="relative">
                  <input
                    className="form-control"
                    type="email"
                    required
                    placeholder="Type your email address..."
                    pattern="[a-z0-9._%+-]+@[a-z0-9.-]+\.[a-z]{2,3}$"
                    value={accounttitle}
                    onChange={(e) => setEmail(e.target.value)}
                  />
                  <i className="fa fa-envelope"></i>
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="contactNumber">Branch Code </label>
                <div className="relative">
                  <input
                    className="form-control"
                    type="text"
                    maxLength="10"
                    onInput={(e) =>
                      (e.target.value = e.target.value.replace(/[^0-9]/g, ""))
                    }
                    required
                    placeholder="Type your Mobile Number..."
                    value={branchcode}
                    onChange={(e) => setContactNumber(e.target.value)}
                  />
                  <i className="fa fa-phone"></i>
                </div>
              </div>
              <div className="form-group">
                <label htmlFor="companyName">Account  Number:</label>
                <div className="relative">
                  <input
                    className="form-control"
                    type="url"
                    pattern="https?://.+"
                    required
                    placeholder="Mention your company link(url)..."
                    value={accountNumber}
                    onChange={(e) => setCompanyName(e.target.value)}
                  />
                  <i className="fa fa-building"></i>
                </div>
              </div>
             
              <div className="tright">
                <button className="movebtn movebtnsu" type="submit">
                  UpDate <i className="fa fa-fw fa-paper-plane"></i>
                </button>
              </div>
            </form>

 {/* attachment*/}
            <form className="form" onSubmit={handleSubmit}>
            <h2>Attachment</h2>
            <div className="form-group">
            <label htmlFor="attachment"> Joining Letter:</label>
            <div className="relative">
              <div className="input-group">
                <label className="input-group-btn">
                  <span className="btn btn-default">
                    Browse&hellip;{" "}
                    <input type="file" style={{ display: "none" }} multiple />
                  </span>
                </label>
                <input
                  type="text"
                  className="form-control"
                  required
                  placeholder="Attachment..."
                  readOnly
                  value={attachment}
                  onChange={(e) => setAttachment(e.target.value)}
                />
                <i className="fa fa-link"></i>
              </div>
            </div>
          </div>
          <div className="form-group">
          <label htmlFor="attachment">Company Agreement:</label>
          <div className="relative">
            <div className="input-group">
              <label className="input-group-btn">
                <span className="btn btn-default">
                  Browse&hellip;{" "}
                  <input type="file" style={{ display: "none" }} multiple />
                </span>
              </label>
              <input
                type="text"
                className="form-control"
                required
                placeholder="Attachment..."
                readOnly
                value={attachment}
                onChange={(e) => setAttachment(e.target.value)}
              />
              <i className="fa fa-link"></i>
            </div>
          </div>
        </div>
       
          
           
            <div className="tright">
              <button className="movebtn movebtnsu" type="submit">
                Submit <i className="fa fa-fw fa-paper-plane"></i>
              </button>
            </div>
          </form>
          </div>
        </div>
     
    </div>
  );
}

export default UserProfileForm;
