import React from 'react';
import './reports.css';

const Reports = () => {
  return (
    <div className="content">
      <section className="bg-table">
        {/* for demo wrap */}
        <h1>Employee Reports</h1>
        <div className="tbl-header">
          <table cellPadding="0" cellSpacing="0" border="0">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Designation</th>
                <th>Profile</th>
              </tr>
            </thead>
          </table>
        </div>
        <div className="tbl-content">
          <table cellPadding="0" cellSpacing="0" border="0">
            <tbody>
              <tr>
                <td>Shakeel Ayaz</td>
                <td>shakeelayaz954@gmail.com</td>
                <td>Webdeveloper</td>
                <td><button>profile</button></td>
              </tr>
              <tr>
                <td>Shakeel Ayaz</td>
                <td>shakeelayaz954@gmail.com</td>
                <td>Webdeveloper</td>
                <td><button>profile</button></td>
              </tr>
              <tr>
                <td>Shakeel Ayaz</td>
                <td>shakeelayaz954@gmail.com</td>
                <td>Webdeveloper</td>
                <td><button>profile</button></td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};

export default Reports;
