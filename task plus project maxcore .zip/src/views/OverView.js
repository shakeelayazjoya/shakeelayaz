import React from "react";
import { Card, Row } from "reactstrap";

function OverView() {
  return (
    <>
      <div className="content">
        <Row xs={1} sm ={2} md={4} lg={4}  className="g-3" style={{fontSize:'17px'}}> {/* Responsive Grid */}
          <div>
            <Card className="card-stats">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <i className="nc-icon nc-globe text-warning"  style={{fontSize:'30px'}}/>
                <p>Total Team Members</p>
              </div>
              <p>20</p>
            </Card>
          </div>
          <div>
            <Card className="card-stats">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <i className="nc-icon nc-globe text-warning"style={{fontSize:'30px'}} />
                <p>Currently Working</p>
              </div>
              <p>10</p>
            </Card>
          </div>
          <div>
            <Card className="card-stats">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <i className="nc-icon nc-globe text-warning" style={{fontSize:'30px'}} />
                <p>Currently On Break</p>
              </div>
              <p>3</p>
            </Card>
          </div>
          <div>
            <Card className="card-stats">
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <i className="nc-icon nc-globe text-warning" style={{fontSize:'30px'}} />
                <p>Currently Stopped Work</p>
              </div>
              <p>0</p>
            </Card>
          </div>
        </Row>
      </div>
    </>
  );
}

export default OverView;
