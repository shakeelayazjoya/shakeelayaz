import React from 'react'

const yoga = () => {
  return (
    <div className='content'>yoga</div>
  )
}

export default yoga