import React from 'react'
import './ManageHolydays.css'

const ManageHolydays = () => {
  return (
    <div className='content'>
    <table className='holidays-table'>
    <thead style={{fontSize:'.85em ', letterSpacing:'.1em',textTransform:'uppercase', background:'#0f82e6', color:"black"}} >
       <tr className='table-trs'>
         <th><label>Holiday Title</label></th>
         <th><label>	Holiday Date</label></th>
         <th><label>Day</label></th>
         <th><label>Session</label></th>
         <th><label>Holiday Type</label></th>
         <th><label></label></th>
         <th><label></label></th>
       </tr> 
     </thead>
     <tbody>
       <tr>
     <td data-label="Invoice">Eid Holidays</td>
         <td data-label="Details">		09 Apr, 2024</td>
         <td data-label="Due Date">Tuesday</td>
         <td data-label="Amount">Full Day	</td>
         <td>Public Holiday	</td>
         <td data-label="Payment"><button class="btn-invoice">Edit</button></td>
         <td data-label="Payment"><button class="btn-invoice">Delete</button></td>
       </tr>
        <tr>
        <td>Eid HoliDays</td>
        <td data-label="Details">		09 Apr, 2024</td>
        <td data-label="Due Date">Tuesday</td>
        <td data-label="Amount">Full Day	</td>
        <td>Public Holiday	</td>
        <td data-label="Payment"><button class="btn-invoice">Edit</button></td>
        <td data-label="Payment"><button class="btn-invoice">Delete</button></td>
       </tr>
         <tr>
         <td>Eid HoliDays</td>
         <td data-label="Details">		09 Apr, 2024</td>
         <td data-label="Due Date">Tuesday</td>
         <td data-label="Amount">Full Day	</td>
         <td>Public Holiday	</td>
         <td data-label="Payment"><button class="btn-invoice">Edit</button></td>
         <td data-label="Payment"><button class="btn-invoice">Delete</button></td>
       </tr>
        <tr>
        <td>Eid HoliDays</td>
        <td data-label="Details">		09 Apr, 2024</td>
        <td data-label="Due Date">Tuesday</td>
        <td data-label="Amount">Full Day	</td>
        <td>Public Holiday	</td>
        <td data-label="Payment"><button class="btn-invoice">Edit</button></td>
        <td data-label="Payment"><button class="btn-invoice">Delete</button></td>
       </tr>
     </tbody>
   </table>
              
    
    </div>
  )
}

export default ManageHolydays