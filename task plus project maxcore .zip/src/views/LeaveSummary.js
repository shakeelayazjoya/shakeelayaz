import React from 'react'

const LeaveSummary = () => {
  return (
    <div className='content'>LeaveSummary</div>
  )
}

export default LeaveSummary