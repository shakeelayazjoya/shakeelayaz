import React from 'react'

const ManageLeave = () => {
  return (
    <div className='content'>ManageLeave</div>
  )
}

export default ManageLeave