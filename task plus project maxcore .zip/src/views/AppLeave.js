import { useState } from "react";
import "./appleave.css";
const AppLeave = () => {
  const [activeTab, setActiveTab] = useState("home");

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
  };

  return (
    <>
      <div className="content">
        <h4>Apply Leave Details</h4>
        <div className="tile" id="tile-1" style={{ cursor: "pointer" }}>
          {/* Nav tabs */}
          <ul className="nav nav-tabs nav-justified" role="tablist">
            <div className="slider"></div>
            <li className="nav-item">
              <a
                className={"nav-link " + (activeTab === "home" ? "active" : "")}
                onClick={() => handleTabClick("home")}
                role="tab"
                aria-controls="home"
                aria-selected={activeTab === "home"}
              >
                UpComing
              </a>
            </li>
            <li className="nav-item">
              <a
                className={
                  "nav-link " + (activeTab === "profile" ? "active" : "")
                }
                onClick={() => handleTabClick("profile")}
                role="tab"
                aria-controls="profile"
                aria-selected={activeTab === "profile"}
              >
                Past Leave
              </a>
            </li>
            <li className="nav-item">
              <a
                className={
                  "nav-link " + (activeTab === "contact" ? "active" : "")
                }
                onClick={() => handleTabClick("contact")}
                role="tab"
                aria-controls="contact"
                aria-selected={activeTab === "contact"}
              >
                <button className="m-0" >Apply for Leave</button>
              </a>
            </li>
          </ul>

          {/* Tab panes */}
          <div className="tab-content">
            <div
              className={
                "tab-pane fade" + (activeTab === "home" ? " show active" : "")
              }
              id="home"
              role="tabpanel"
              aria-labelledby="home-tab"
            >
              You have no upcoming leaves
            </div>
            <div
              className={
                "tab-pane fade" +
                (activeTab === "profile" ? " show active" : "")
              }
              id="profile"
              role="tabpanel"
              aria-labelledby="profile-tab"
            >
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <p className="text-primary">19 Apr, 2024</p>
                <p>1 Day</p>
                <p> Casual Leave</p>
                <p
                  style={{
                    border: "1px solid ",
                    background: "green",
                    color: "white",
                    padding: "5px",
                    borderRadius: "5px",
                  }}
                >
                  Approved By Shakeel
                </p>
                <p>Reason</p>
                <button className="m-0">Edit</button>
                <button className="m-0">Delete</button>
              </div>{" "}
              <hr />
              <div style={{ display: "flex", justifyContent: "space-between" }}>
                <p className="text-primary">19 Apr, 2024</p>
                <p>1 Day</p>
                <p> Casual Leave</p>
                <p
                  style={{
                    border: "1px solid ",
                    background: "orange",
                    color: "white",
                    padding: "5px",
                    borderRadius: "5px",
                  }}
                >
                  Rejected By Shakeel
                </p>
                <p>Reason</p>
                <button className="m-0">Edit</button>
                <button className="m-0">Delete</button>
              </div>
            </div>

            <div
              className={
                "tab-pane fade" +
                (activeTab === "contact" ? " show active" : "")
              }
              id="contact"
              role="tabpanel"
              aria-labelledby="contact-tab"
            >
                <div className="container pt-4">
                <h1 className="text-dark">Apply for Leave</h1>
                    <div className="row">
                    
                        <div className="col-md-6 card">
                        <p>Employee Name</p>
                        <select id="job" style={{height:'7vh'}}>
                        <optgroup label="Name">
                          <option value="frontend_developer">Shakeel Ayaz </option>
                          <option value="php_developer">Danish</option>
                          <option value="python_developer">Awais</option>
                         
                        </optgroup>
                       
                      </select>
                      <p className="pt-3">Leave Type</p>
                      <select id="job" style={{height:'7vh'}}>
                      <optgroup label="Leave">
                      <option value="frontend_developer">Work Leave</option>
                      <option value="php_developer">Sick Leave</option>
                      <option value="python_developer">Casual Leave</option>
                     
                    </optgroup>
                     
                    </select>
                    <p className="pt-3">Leave Date</p>
                    <input type="date" name="" id=""  style={{width:'100%'}}/>
                    <p className="pt-3">Leave Deatils</p>
                    <textarea name="leave reason" id="" rows='5'></textarea>
                    <button>Apply Leave</button>
                        
                        
                        </div>
                       
                    </div>
                </div>
            
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default AppLeave;
