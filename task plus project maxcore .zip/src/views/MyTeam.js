
import React from "react";
// react plugin used to create charts
import { Link } from "react-router-dom";
import './myteam.css'

import {
  Card,
  CardHeader,
  CardBody,
  CardFooter,
  CardTitle,
  Row,
  Col,
} from "reactstrap";
// core components
import {
  dashboard24HoursPerformanceChart,
  dashboardEmailStatisticsChart,
  dashboardNASDAQChart,
} from "variables/charts.js";

function MyTeam() {
  return (
    <>
      <div className="content">
      <div className="container">
      <div className="row">
        <div className="col-md-4">
        <div class="card bg-light-subtle mt-4" style={{cursor:'pointer'}}>
        <Link to='/admin/employeeprofile' style={{textDecoration:'none'}}>
        <div class="card-body">
        <div class="text-section" style={{display:'flex', justifyContent:'space-between'}}>
          <h5 class="card-title fw-bold text-dark" >Shakeel Ayaz</h5>
          <p style={{border:'1px solid ', background:'#4e73df', color:'white', borderRadius:'5px'}} className="p-1">Online</p>
        </div>
        <div class="cta-section pt-3" style={{display:'flex', justifyContent:'space-between'}}>
          <p style={{fontSize:'17px', color:'black'}}>check in <span>00:00</span></p>
          <p style={{fontSize:'17px'}}>check out <span>11:00</span></p>
          
        </div>
      </div>
        </Link>
      </div>
        </div>
      </div>
    </div>
        
       
      </div>
    </>
  );
}

export default MyTeam;
