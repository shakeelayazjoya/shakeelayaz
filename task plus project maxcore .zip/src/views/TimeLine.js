import React from 'react'

const TimeLine = () => {
  return (
    <div className='content'>TimeLine</div>
  )
}

export default TimeLine