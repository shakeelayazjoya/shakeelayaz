import React from 'react'

const Billings = () => {
  return (
    <div className='content'>Billings</div>
  )
}

export default Billings