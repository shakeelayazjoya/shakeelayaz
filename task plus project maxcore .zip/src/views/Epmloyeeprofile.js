import React from "react";

const EmployeeProfile = () => {
  return (
    <div className="content">
      <div className="container">
        <div className="row">
          <div className="col-md-4 col-lg-6 col-sm-4">
            <div
              className="card bg-light-subtle mt-4"
              style={{ cursor: "pointer" }}
            >
              <div className="card-body">
                <div
                  className="text-section"
                  style={{
                    display: "flex",
                    justifyContent: "space-between"
                  }}
                >
                  <h5 className="card-title fw-bold">Shakeel Ayaz</h5>
                  <p
                    style={{
                      border: "1px solid",
                      background: "#4e73df",
                      color: "white",
                      borderRadius: "5px"
                    }}
                    className="p-1"
                  >
                    Online
                  </p>
                </div>
                <p>Shakeelayaz954@gmail.com</p>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Another section of individual cards */}

      <div className="container">
        <div className="row">
          <div className="col-md-4 col-sm-6 col-12">
            <div
              className="card bg-light-subtle"
              style={{ cursor: "pointer" }}
            >
              <div className="card-body">
                <h6>Total Active Hour</h6>
                <p>00HR 00 M</p>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-6 col-12">
            <div
              className="card bg-light-subtle"
              style={{ cursor: "pointer" }}
            >
              <div className="card-body">
                <h6>Active Time</h6>
                <p>00HR 00 M</p>
              </div>
            </div>
          </div>
          <div className="col-md-4 col-sm-6 col-12">
            <div
              className="card bg-light-subtle"
              style={{ cursor: "pointer" }}
            >
              <div className="card-body">
                <h6>Idle Time Spent %</h6>
                <p>00HR 00 M</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default EmployeeProfile;
