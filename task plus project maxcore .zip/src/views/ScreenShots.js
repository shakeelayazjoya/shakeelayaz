import React from 'react';
import './screenshots.css'; // Make sure to adjust the path if needed
import mike from '../assets/img/mike.jpg';

const ScreenShots = () => {
  return (
    <div className='content'>
     <div className="container-fluid">
     <div className="row">
     <div className="col-md-4">
       <div className="card">
         <h2 className="card-title">Shakeel Ayaz</h2>
         <div className="image-row">
           <img src={mike} alt="Image 1" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 2" className="image img-fluid" style={{height:'100px'}} />
         </div>
         <div className="image-row">
           <img src={mike} alt="Image 3" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 4" className="image img-fluid" style={{height:'100px'}} />
         </div>
       </div>
     </div>
     <div className="col-md-4">
       <div className="card">
         <h2 className="card-title">Nouman Nawaz  </h2>
         <div className="image-row">
           <img src={mike} alt="Image 1" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 2" className="image img-fluid" style={{height:'100px'}} />
         </div>
         <div className="image-row">
           <img src={mike} alt="Image 3" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 4" className="image img-fluid" style={{height:'100px'}} />
         </div>
       </div>
     </div>
     <div className="col-md-4">
       <div className="card">
         <h2 className="card-title">Danish Sharjeel</h2>
         <div className="image-row">
           <img src={mike} alt="Image 1" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 2" className="image img-fluid" style={{height:'100px'}} />
         </div>
         <div className="image-row">
           <img src={mike} alt="Image 3" className="image img-fluid" style={{height:'100px', marginRight: '10px'}} />
           <img src={mike} alt="Image 4" className="image img-fluid" style={{height:'100px'}} />
         </div>
       </div>
     </div>
   </div>
     </div>
    </div>
  );
}

export default ScreenShots;
