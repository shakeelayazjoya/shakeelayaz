import React from 'react'

const AppSummary = () => {
  return (
    <div className='content'>AppSummary</div>
  )
}

export default AppSummary