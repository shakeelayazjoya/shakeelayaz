import React from 'react'

const ReviewApps = () => {
  return (
    <div className='content'>ReviewApps</div>
  )
}

export default ReviewApps