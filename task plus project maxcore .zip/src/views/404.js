import React from 'react'

const Error = () => {
  return (
    <div className='content'>
        <h1>404 Page</h1>
    </div>
  )
}

export default Error;