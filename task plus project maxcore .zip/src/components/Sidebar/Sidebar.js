import React from "react";
import { NavLink, useLocation } from "react-router-dom";
import { Nav } from "reactstrap";
// javascript plugin used to create scrollbars on windows
import PerfectScrollbar from "perfect-scrollbar";
import './sidebar.css'


var ps;

function Sidebar(props) {
  const location = useLocation();
  const sidebar = React.useRef();
  // verifies if routeName is the one active (in browser input)
  const activeRoute = (routeName) => {
    return location.pathname.indexOf(routeName) > -1 ? "active" : "";
  };
  React.useEffect(() => {
    if (navigator.platform.indexOf("Win") > -1) {
      ps = new PerfectScrollbar(sidebar.current, {
        suppressScrollX: true,
        suppressScrollY: false,
      });
    }
    return function cleanup() {
      if (navigator.platform.indexOf("Win") > -1) {
        ps.destroy();
      }
    };
  });
  return (
    <div
      className="sidebar "
      data-color={props.bgColor}
      data-active-color={props.activeColor}
    >
      <div className="logo">
        <h2 className="simple-text logo-normal" id="logo-main" style={{fontSize:"28px"}}>Task Plus</h2>
      </div>
      <div className="sidebar-wrapper" ref={sidebar}>
        <Nav>
        <p className="text-light">RealTime</p>
              <li>
                <NavLink to='/admin/dashboard' className="nav-NavLink">
                <i class="fa-solid fa-chart-pie"></i> OverView
                </NavLink>
              </li>
              <li>
                <NavLink to='/admin/myteam' className="nav-NavLink">
                
                <i class="fa-solid fa-user-plus"></i>My Team
                </NavLink>
              </li>
              <p className="text-white">Proof of work </p>
              <li>
              <NavLink to='/admin/screenshots' className="nav-NavLink">
              
              <i class="fa-solid fa-photo-film"></i>ScreenShots
              </NavLink>
            </li>
            <li>
            <NavLink to='/admin/timesheet' className="nav-NavLink">
            
            <i class="fa-solid fa-business-time"></i>Time Sheet
            </NavLink>
          </li>
          <li>
          <NavLink to='/admin/timeline' className="nav-NavLink">
          
          <i class="fa-solid fa-user-plus"></i>Time Line
          </NavLink>
        </li>
        <li>
        <NavLink to='/admin/reports' className="nav-NavLink">
        
        <i class="fa-solid fa-sim-card"></i>Reports
        </NavLink>
      </li>
      <p className="text-white">Leave Management</p>
      <li>
      <NavLink to='/admin/appleave' className="nav-NavLink">
      
      <i class="fa-regular fa-calendar"></i>App Leave
      </NavLink>
    </li>
    <li>
    <NavLink to='/admin/leavesummary' className="nav-NavLink">
    
    <i class="fa-regular fa-calendar-days"></i>Leave Summary 
    </NavLink>
  </li>
  <li>
  <NavLink to='/admin/manageleaves' className="nav-NavLink">
  <i class="fa-regular fa-star"></i>Manage Leave 
  </NavLink>
</li>
<li>
<NavLink to='/admin/manageholidays' className="nav-NavLink">

<i class="fa-solid fa-user-plus"></i>Manage Holidays 
</NavLink>
</li>
<p className="text-white">Apps Usage</p>
<li>
<NavLink to='/admin/reviewapps' className="nav-NavLink">

<i class="fa-solid fa-check"></i>Review Apps 
</NavLink>
</li>
<li>
<NavLink to='/admin/appsummary' className="nav-NavLink">

<i class="fa-regular fa-clock"></i>App Summary
</NavLink>
</li>
<p className="text-white">Configuration</p>
<li>
<NavLink to='/admin/userprofile' className="nav-NavLink">

<i class="fa-solid fa-gear"></i>Employee Profile 
</NavLink>
</li>
<li>
<NavLink to='/admin/billing' className="nav-NavLink">

<i class="fa-regular fa-credit-card"></i>Billing
</NavLink>
</li>
        </Nav>
      </div>
    </div>
  );
}

export default Sidebar;
