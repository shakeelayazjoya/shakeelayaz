import React from 'react';
import { Link } from 'react-router-dom';
import './emailverification.css'
function VerificationComponent() {
  return (
    <div className="container-fluid bg-body-tertiary d-block">
      <div className="row justify-content-center">
        <div className="col-12 col-md-6 col-lg-4" style={{ minWidth: '500px' }}>
          <div className="card bg-white mb-5 mt-5 border-0" style={{ boxShadow: '0 12px 15px rgba(0, 0, 0, 0.02)' }}>
            <div className="card-body p-5 text-center border">
              <h4>Verify</h4>
              <p>Your code was sent to you via email</p>

              <div className="otp-field mb-4">
                <input type="number" />
                <input type="number"  />
                <input type="number" />
                <input type="number"  />
                <input type="number"  />
                <input type="number"  />
              </div>

              <Link to='/'> 
                <button className="  mb-3" style={{background:'#8d5dff', padding:'10px 20px' }}>
                Verify
                </button>
              </Link>

              <p className="resend text-muted mb-0">
                Didn't receive code? <a href="">Request again</a>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default VerificationComponent;
