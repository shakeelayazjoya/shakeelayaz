import React from "react";
import logo from "../Auth/logo.png";
import "./signup.css";
import { Link } from "react-router-dom";


const Signup = () => {
  return (
    <>
    <section className="form-card-field">
    <div className="form-card-grid">

      <h1 className="form-title text-dark ">
        Task Plus
       
      </h1>
      <form action="." className="form-card" name="form-card">

        <label htmlFor="form-card" className="main-label">

          {/* required elements */}
          <div className="main-ele">
            <input type="text" placeholder="First Name" required />
            <input type="text" placeholder="Company Name " required />
            <input type="email" placeholder="Email" required />
           
           
           
          </div>

          {/* less required elements */}
          <div className="less-ele">
          <input type="text" placeholder="Last Name " required />
          <input type="text" placeholder="Designation  " required />
          <input type="password" placeholder="Password" required />
            

            

           
          </div>
        </label>

      </form>
      <Link to='/emailverification'><button type="button">Sign Up</button></Link>

    </div>
  </section>
    
    </>
  );
};

export default Signup;
