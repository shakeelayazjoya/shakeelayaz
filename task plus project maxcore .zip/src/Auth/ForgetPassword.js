import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./forgetpassword.css";

const ForgetPassword = () => {
  return (
    <div className="element">
      <div className="container forgetpassword">
        <div className="card">
          <h2>ForgetPassWord</h2>
          <form>
            <input
              type="text"
              id="username"
              name="username"
              placeholder="Username"
              required
              style={{width:'100%'}}
            />
            <input
              type="Email"
              id="password"
              name="Email"
              placeholder="Email"
              required
              style={{width:'100%'}}
            />
            <Link to='/signup'>
              <button type="submit">ForGetPassWord</button>
            </Link>
          </form>
        </div>
      </div>
    </div>
  );
};

export default ForgetPassword;
