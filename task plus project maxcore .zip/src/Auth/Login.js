import React from "react";
import logo from "../Auth/logo.png";
import "./login.css";
import { Link } from "react-router-dom";

const Login = () => {
  return (
    <>
      {/*
      <div classNameName="text-center main-div pt-5 pb-2">
        <div classNameName="" style={{display:'flex', justifyContent:'center', alignItems:'center'}}>
          <img src={logo} alt="" />
        </div>
        <h3 classNameName="text-center p-2">
          Register your organization in TaskPlus
        </h3>
      </div>
      <div
        classNameName="form-card text-center border"
        style={{ width: "80%", maxWidth: "400px", margin: "auto" }}
      >
        <h2 classNameName="pb-3">Login To Your Account</h2>
        <div>
          <input
            type="email"
            classNameName="login-text border"
            placeholder="Your Email"
            required
          />
        </div>
        <div>
          <input
            type="password"
            classNameName="login-password border"
            placeholder="Your Password"
            required
          />
        </div>

        <Link to="/forgetpassword">
          <button
            classNameName="forget-password bg-white"
            style={{ border: "none", outline: "none" }}
          >
            Forgot Password?
          </button>
        </Link>

        <div classNameName="pt-2">
          <Link to="/admin/Dashboard">
            {" "}
            <button
              style={{
                padding: "7px 50px",
                fontSize: "20px",
                fontWeight: "bold",
                background: "#4287f5",
                border: "none",
                color: "white",
              }}
            >
              Log In
            </button>
          </Link>
        </div>
      </div>

      <div classNameName="text-center p-5">
        <span style={{ fontSize: "19px" }}>Not yet registered? </span>
        <Link
          to="/signup"
          style={{
            fontSize: "21px",
            fontWeight: "bold",
            color: "#4287f5",
            cursor: "pointer",
          }}
        >
          Sign Up
        </Link>
      </div>
*/}

   
          <div className="LoginForm pt-4">
          <div className="col-lg-6 d-flex align-items-center justify-content-center">
          <div className="form-2-wrapper">
            <div className="logo text-center">
              <h2>Task Plus</h2>
            </div>
            <h2 className="text-center mb-4">LogIn Into Your Account</h2>
            <form action="#">
              <div className="mb-3 form-box">
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  name="email"
                  placeholder="Enter Your Email"
                  required
                />
              </div>
              <div className="mb-3">
                <input
                  type="password"
                  className="form-control"
                  id="password"
                  name="password"
                  placeholder="Enter Your Password"
                  required
                />
              </div>
              <div className="mb-3">
                <div className="form-check">
                  <input
                    type="checkbox"
                    className="form-check-input"
                    id="rememberMe"
                  />
                  <label className="form-check-label" for="rememberMe">
                    Remember me
                  </label>
                  <Link to='/forgetpassword'>
                  <a
                    href="forget-3.html"
                    className="text-decoration-none float-end"
                  >
                    Forget Password
                  </a>
                  </Link>
                </div>
              </div>
             <Link to='/admin/Dashboard'>
             <button
             type="submit"
             className="btn btn-outline-secondary login-btn w-100 mb-3"
           >
             Login
           </button>
             </Link>
              <div className="social-login mb-3 type--A">
                <h5 className="text-center mb-3">Social Login</h5>
                <button className="btn btn-outline-secondary  mb-3">
                  <i className="fa-brands fa-google text-danger"></i> Sign
                  With Google
                </button>
                <button className="btn btn-outline-secondary mb-3">
                  <i className="fa-brands fa-facebook-f text-primary"></i>{" "}
                  Sign With Facebook
                </button>
              </div>
            </form>

            <p className="text-center register-test mt-3">
              Don't have an account?{" "}
              <Link to='/signup'><a href="register-3.html" className="text-decoration-none">
              Register here
            </a></Link>
            </p>
          </div>
        </div>
          
          </div>
       
    </>
  );
};

export default Login;
