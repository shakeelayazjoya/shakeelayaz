
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter, Route, Routes, Navigate } from "react-router-dom";

import "bootstrap/dist/css/bootstrap.css";
import "assets/scss/paper-dashboard.scss?v=1.3.0";
import "assets/demo/demo.css";
import "perfect-scrollbar/css/perfect-scrollbar.css";

import AdminLayout from "layouts/Admin.js";
import Login from "Auth/Login";
import Error from "views/404";
import Signup from "Auth/Signup";
import ForgetPassword from "Auth/ForgetPassword";
import EmailVerification from "Auth/EmailVerfication";

const root = ReactDOM.createRoot(document.getElementById("root"));

root.render(
  <BrowserRouter>
    <Routes>
      <Route path="/" element={<Login/>} />
      <Route path="/signup" element={<Signup/>} />
      <Route path="/forgetpassword" element={<ForgetPassword/>} />
      <Route path="/emailverification" element={<EmailVerification/>} />
      <Route path="/admin/*" element={<AdminLayout />} />
      <Route path="*" element={<Error />} />
      <Route path="/admin/" element={<Navigate to="/admin/dashboard" replace />} />
    </Routes>
  </BrowserRouter>
);
