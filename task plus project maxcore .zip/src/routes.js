

import Icons from "views/Icons.js";

import MyTeam from "views/MyTeam";

import OverView from "views/OverView";
import ScreenShots from "views/ScreenShots";
import TimeSheet from "views/TimeSheet";
import TimeLine from "views/TimeLine";
import Reports from "views/Reports";
import AppLeave from "views/AppLeave";
import LeaveSummary from "views/LeaveSummary";
import ManageHolydays from "views/ManageHolydays";
import ReviewApps from "views/ReviewApps";
import AppSummary from "views/AppSummary";
import Settings from "views/Settings";
import Billings from "views/Billings";
import ManageLeave from "views/ManageLeave";
import Epmloyeeprofile from "views/Epmloyeeprofile";
import UserProfile from 'views/UserProfile'


var routes = [
 
  {
    path: "/dashboard",
    name: "Dashboard",
    icon: "nc-icon nc-bank",
    component: <OverView />,
    layout: "/admin",
  },
  {
    path: "/myteam",
    name: "MyTeam",
    component: <MyTeam />,
    layout: "/admin",
  },
  {
    path: "/screenshots",
    name: "Screen Shots",
    component: <ScreenShots />,
    layout: "/admin",
  },
  {
    path: "/employeeprofile",
    name: "EmployeeProfile",
    component: <Epmloyeeprofile />,
    layout: "/admin",
  },
  {
    path: "/timesheet",
    name: "timesheet",
    component: <TimeSheet />,
    layout: "/admin",
  },
  {
    path: "/userprofile",
    name: "User Profile",
    component: <UserProfile />,
    layout: "/admin",
  },
  {
    path: "/icons",
    name: "Icons",
    icon: "nc-icon nc-diamond",
    component: <Icons />,
    layout: "/admin",
  },
  {
    path: "/timeline",
    name: "timeline",
    icon: "nc-icon nc-pin-3",
    component: <TimeLine />,
    layout: "/admin",
  },
  {
    path: "/reports",
    name: "reports",
    icon: "nc-icon nc-bell-55",
    component: <Reports />,
    layout: "/admin",
  },
  {
    path: "/appleave",
    name: "appleave",
    icon: "nc-icon nc-single-02",
    component: <AppLeave />,
    layout: "/admin",
  },
  {
    path: "/leavesummary",
    name: " leavesummary",
    icon: "nc-icon nc-tile-56",
    component: <LeaveSummary />,
    layout: "/admin",
  },
  {
    path: "/manageleaves",
    name: "manageleave",
    component: <ManageLeave />,
    layout: "/admin",
  },
  {
    path: "/manageholidays",
    name: "manageholdays",
    component: <ManageHolydays />,
    layout: "/admin",
  },
  {
    path: "/reviewapps",
    name: "reviewapps",
    component: <ReviewApps />,
    layout: "/admin",
  },
  
  {
    path: "/appsummary",
    name: "appsummary",
    component: <AppSummary />,
    layout: "/admin",
  },
  
  {
    path: "/setting",
    name: "setting",
    component: <Settings />,
    layout: "/admin",
  },
  {
    path: "/billing",
    name: "billing",
    component: <Billings />,
    layout: "/admin",
  },
];
export default routes;
